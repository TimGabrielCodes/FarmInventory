package in.bushansirgur.dao;

import in.bushansirgur.model.Login;

public interface LoginDAO {
	String loginCheck(Login loginBean);
}
