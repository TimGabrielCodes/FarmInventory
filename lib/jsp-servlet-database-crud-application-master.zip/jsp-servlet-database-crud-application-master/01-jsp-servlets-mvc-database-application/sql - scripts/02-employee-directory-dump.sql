use employeedirectory;

insert into tbl_employee(name, dob, department)values("Jhon", "12-12-1991", "Marketing");

insert into tbl_employee(name, dob, department)values("Sara", "21-05-1992", "Testing");

insert into tbl_employee(name, dob, department)values("Paul", "23-04-1988", "Development");

insert into tbl_employee(name, dob, department)values("David", "18-03-1989", "Support");

insert into tbl_login(email, password)values("b2techdvg@gmail.com", "123456789");

insert into tbl_login(email, password)values("bushan@bushansirgur.in", "123456789");

select * from tbl_employee;